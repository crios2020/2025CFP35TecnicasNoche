import java.util.Scanner;
public class sumar{
    public static void main(String[] args){
        //Sumar números
        System.out.println("Ingrese número1: ");
        double numero1=new Scanner(System.in).nextDouble();
        System.out.println("Ingrese número1: ");
        double numero2=new Scanner(System.in).nextDouble();
        System.out.println("Suma: "+(numero1+numero2));
    }
}