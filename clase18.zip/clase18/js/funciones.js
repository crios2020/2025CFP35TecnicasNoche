function diaSemana(){
    fecha = new Date()
    diaSem = fecha.getDay()
    semana=['domingo','lunes','martes','miércoles','jueves','viernes','sábado']
    return semana[diaSem]
}
