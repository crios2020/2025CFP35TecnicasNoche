function diaSemana(){
    fecha = new Date()
    diaSem = fecha.getDay()
    semana=['domingo','lunes','martes','miércoles','jueves','viernes','sábado']
    return semana[diaSem]
}

function nombreMes(){
    fecha = new Date()
    mes=fecha.getMonth()
    meses=['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre']
    return meses[mes]
}

function zonaHoraria(){
    zona=Intl.DateTimeFormat().resolvedOptions().timeZone
    zona=zona.replace("/"," ")
    zona=zona.replace("/"," ")
    zona=zona.replace("_"," ")
    return zona
}

function sensacionTemperatura(temperatura){
    frase=""
    if(temperatura<5)                       frase+="frio polar"      
    if(temperatura>=5 && temperatura<10)    frase+="frio" 
    if(temperatura>=10 && temperatura<15)   frase+="fresco"
    if(temperatura>=15 && temperatura<25)   frase+="agradable"   
    if(temperatura>=25 && temperatura<30)   frase+="calido"   
    if(temperatura>=30)                     frase+="muy caluroso" 
    return frase
}

function sensacionClima(clima, temperatura){
    frase=""
    if(temperatura<16) frase+=", salir abrigado"
    if(clima.includes("lluvi") || clima.includes("llov")){
        frase+=", salir con paraguas"
        if(temperatura<15)  frase+=", hoy esta para hacer tortafritas!"
    }
    return frase   
}
function momento(){
    fecha=new Date()
    hora=fecha.getHours()
    momentos=[
        'es momento de dormir',                             //0
        'es momento de dormir',                             //1
        'es momento de dormir',                             //2
        'es momento de dormir',                             //3
        'es momento de dormir',                             //4
        'es momento de dormir',                             //5
        'esta amaneciendo',                                 //6
        'es momento de desayunar',                          //7
        'estamos de mañana',                                //8
        'estamos de mañana',                                //9
        'es momento de tomar mate',                         //10
        'estamos de mañana',                                //11
        'es momento de almorzar',                           //12
        'es de tarde',                                      //13
        'es de tarde',                                      //14
        'es momento de tomar mate',                         //15
        'es de tarde',                                      //16
        'es momento de merendar',                           //17
        'esta anocheciendo',                                //18
        'esta anocheciendo',                                //19
        'es momento de cenar',                              //20
        'es momento de ver series',                         //21
        'es momento de tomar una cerveza',                  //22
        'es momento de ver series'                          //23
    ]
    return momentos[hora]
}

function estacion(){
    fecha = new Date()
    diaSem = fecha.getDay()
    mes=fecha.getMonth()
    frase=""
    switch(mes){
        case 0:  case 1:            frase+="verano";       break
        case 3:  case 4:            frase+="otoño";        break 
        case 6:  case 7:            frase+="invierno";     break
        case 9:  case 10:           frase+="primavera";    break
        case 2:  if(diaMes<21)      frase+="verano"
                 else               frase+="otoño";        break 
        case 5:  if(diaMes<21)      frase+="otoño"
                 else               frase+="invierno";     break
        case 8:  if(diaMes<21)      frase+="invierno"
                 else               frase+="primavera";    break
        case 11: if(diaMes<21)      frase+="primavera"
                 else               frase+="verano";       break 
    }
    return frase
}

function laboral(){
    fecha = new Date()
    diaSem = fecha.getDay()
    laboral=[
        'hoy es día de descanso',                       //0
        'odio los lunes porque hay que ir a trabajar',  //1
        'hoy hay que ir a trabajar',                    //2
        'hoy hay que ir a trabajar',                    //4
        'hoy hay que ir a trabajar',                    //4
        'hoy es viernes y tu cuerpo lo sabe',           //5
        'hoy es día de descanso',                       //6
    ]
    return laboral[diaSem]
}

function efemerides(){
    fecha = new Date()
    diaSem = fecha.getDay()
    mes=fecha.getMonth()
    frase=""
    if(diaMes==29)                  frase+=", hoy es 29 hoy comemos ñoquis!"
    if(diaMes==3 && mes==5)         frase+=", Hoy es el día del aprendiz!"
    if(diaMes==6 && mes==5)         frase+=", Hoy es la noche de los oficios!"
    if(diaMes==20 && mes==5)        frase+=", Hoy es el día de la bandera!"
    if(diaMes==20 && mes==7)        frase+=", Hoy es el día del amigo!"
    return frase
}